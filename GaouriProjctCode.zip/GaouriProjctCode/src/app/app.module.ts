import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {LoginComponent} from './login/login.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EmpComponent } from './emp/emp.component';
import { DisplayComponent } from './Emp/display/display.component';
import { UpdateComponent } from './Emp/update/update.component';
import { InventoryComponent } from './inventory/inventory.component';
import { PricingComponent } from './pricing/pricing.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import {EmpService} from './services/employeeService.component';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,LoginComponent,DashboardComponent, PageNotFoundComponent, InventoryComponent, PricingComponent, HomeComponent, RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,ReactiveFormsModule,HttpClientModule
  ],
  providers: [EmpService],//here u did not put the service as this need to make it accessible for  component 
  bootstrap: [AppComponent]
})
export class AppModule { }
