export class authDto{
    auth_status:boolean;
}