export class loginDto{

    id:string;
    password:string;

}