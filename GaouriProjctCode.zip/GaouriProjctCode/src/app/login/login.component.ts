import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {Router} from "@angular/router";
import { loginDto } from './loginDto.model';
import { authDto } from './auth.model';
import {LoginService} from '../services/login.service';
import { registerDto } from '../register/registerDto.model';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  empLoginForm: FormGroup;
  loginDtoObj: loginDto;
  userCheck: Array<string>;
  status: boolean = false;
  emp:registerDto=new registerDto();
  auth: authDto;
  

  constructor(private fb: FormBuilder,  private route:Router,private loginService:LoginService) { }

  ngOnInit() {

    this.empLoginForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'id': new FormControl(''),
      'password': new FormControl('')
  })

}

    loginEmp(emp:loginDto) {//same identical property for the formcontrolname
     // sessionStorage.setItem("userName",emp.username);
     
      this.loginService.checkUser(emp).subscribe((data) => {//here the data is sent to service class method from componenet
       
          
          if(JSON.stringify(data)!=null){//That means user is registered
          this.route.navigate(['/dashBoard']);
        }
        else{
          alert("You are not authorized please register first");
        }
    },
      err => {
      },
      () => { console.log('Method Executed') }
    );
      
    }

  
    }


