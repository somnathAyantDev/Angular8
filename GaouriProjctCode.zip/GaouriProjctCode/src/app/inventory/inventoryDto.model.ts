export class inventoryDto{

    id:number;
    name:string;
    o_quantity:number;
    e_quantity:number;

}