export class SingleArrayDto{

    e_quantity:number;
}