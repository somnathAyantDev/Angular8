import { Component, OnInit } from '@angular/core';
import { EmpService } from '../services/employeeService.component';
import { inventoryDto } from './inventoryDto.model';
import { pricingDto } from '../pricing/pricingDto.model';
import { SingleArrayDto } from './singleArrayDto.model';


@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  stock: inventoryDto[] = [];
  singleArray:SingleArrayDto[] = []; 
  pricing: pricingDto[] = [];
  i:number;

  constructor(private empService: EmpService) { }

  ngOnInit() {

    this.empService.inventory().subscribe((data) => {
      this.stock = data;

      this.empService.pricing().subscribe((data) => {
        this.pricing = data;


        for(var i=0;i<this.stock.length;i++){
         
          this.singleArray[i].e_quantity = this.stock[i].o_quantity-this.pricing[i].req_quantity;
               }

      },
        err => {
          alert("Product not found !");
        },
        () => { console.log('Method Executed') }
      );
    },
      err => {
        alert("Product not found !");
      },
      () => { console.log('Method Executed') }
    );
  }


  // getExistingQuantity(){

  //     this.pricing.req_quantity
  //   return this.existing;

    // return this.serverStatus;
  // }


}
