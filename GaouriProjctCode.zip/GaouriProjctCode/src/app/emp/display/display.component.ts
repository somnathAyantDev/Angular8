import { DataService } from './../../services/shared-service.service';
import { Component, OnInit } from '@angular/core';
import {EmpService} from '../../services/employeeService.component';
import {registerDto} from '../../register/registerDto.model';
import {Router} from '@angular/router';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {


  emps: registerDto[] = [];
  selectedUser: any;
  id:string;
  constructor(private empService: EmpService,private router: Router,private dataService:DataService) { 
   
  }


  ngOnInit() {

    this.empService.emps().subscribe((data) => {
      this.emps = data;

    },
      err => {
        alert("Employee not found !");
      },
      () => { console.log('Method Executed') }
    );

  }

  RowSelected(u:any){
    this.selectedUser=u;   // declare variable in component.
    }

    updateEmp(e:registerDto){
      this.id=e.id.toString();//converting numeric  to string
     
      this.dataService.changeValue(this.id);
      this.router.navigate(['employee/employeeUpdate']);
    }

    deleteEmp(e:registerDto){
      
      this.empService.deleteEmpById(e).subscribe((data) => {
        
        alert("employee deleted");
        //to display fresh data
        this.empService.emps().subscribe((data) => {
          this.emps = data;
    
        },
          err => {
            alert("Employee not found !");
          },
          () => { console.log('Method Executed') }
        );
    

      },
        err => {
          alert("Employee not found !");
        },
        () => { console.log('Method Executed') }
      );
  
    }

}
