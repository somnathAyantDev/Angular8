import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{DisplayComponent} from './display/display.component';
import{UpdateComponent} from './update/update.component';
import {EmpComponent} from './emp.component';

const routes: Routes = [

  {
    path: '', component: EmpComponent, children: [
      {
        path: 'display', component: DisplayComponent
      },
      
      {
        path: 'employeeUpdate', component: UpdateComponent
      },
       
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmpRoutingModule { }
