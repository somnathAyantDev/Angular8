import { DataService } from './../../services/shared-service.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import{registerDto} from '../../register/registerDto.model';
import {EmpService} from '../../services/employeeService.component';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import {Router} from '@angular/router';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  empForm: FormGroup;
  empId:string;
  emp: registerDto;
  Dept: any = ["IT","Network","Admin","Sales","Operations"];
  constructor(private fb: FormBuilder,private dataService:DataService,private empService:EmpService,private router: Router) { }

  ngOnInit() {
    this.empForm = this.fb.group({
      'id':new FormControl(''),
      'fname' : new FormControl(''),
      'lname' : new FormControl(''),
      'contact' : new FormControl(''),
      'salary' : new FormControl(''),
      'designation' : new FormControl(''),
      'dept':new FormControl('')
    });
    this.dataService.empId.subscribe(value=>this.empId=value);
    
    this.empService.getEmpById(this.empId).subscribe((data) => {
      this.emp = data;
      this.empForm.patchValue({
        id:this.emp.id,
        fname:this.emp.fname,
        lname:this.emp.lname,
        contact:this.emp.contact,
        salary:this.emp.salary,
        designation:this.emp.designation,
        dept:this.emp.dept
      });
    },
      err => {
        alert("Employee not found !");
      },
      () => { console.log('Method Executed') }
    );

  }

  updateEmp(employee:registerDto){
    this.empService.updateEmp(employee).subscribe((data)=>{
     
      this.router.navigate(['employee/display']);
    },
    err=>{
      alert("Employee not updated due to some problem");
    },
    ()=>{console.log("update employee executed");}
    
    )
  }



}
