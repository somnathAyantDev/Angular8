import { Injectable } from '@angular/core';
import { loginDto } from '../login/loginDto.model'
import { EmpService } from './employeeService.component';
import { registerDto } from '../register/registerDto.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})

export class LoginService {

  emps: registerDto[] = [];
  url:string;

  constructor(private empService: EmpService,private nativeHttp: HttpClient) { }

  /*
  public isAuthenticated(emp:loginDto):boolean{

       this.empService.emps().subscribe((data) => {
        this.emps = data;

        for(var i=0;i<=this.emps.length;i++){
          if((this.emps[i].username != emp.id) && this.emps[i].pwd != emp.password){
              return false;   
          }
        }

          alert("Hello "+emp.username);
          localStorage.setItem('username',emp.username);
          localStorage.setItem('password',emp.password);
          return true;

      },
        err => {
          alert("Employee not found !");
         
        }
        
      );

    return true;
    }
    */ 
    checkUser(emp:loginDto)
     {
        
        this.url="http://localhost:3000/saveEmpData"+"?id="+emp.id;
         //return this.nativeHttp.get(this.url).map(res => res.json());
         return this.nativeHttp.get<registerDto>(this.url).pipe(
          tap(data=>console.log(JSON.stringify(data)))
         );
      
    
    }


}
