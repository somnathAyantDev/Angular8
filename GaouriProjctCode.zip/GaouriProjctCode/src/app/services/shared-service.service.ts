import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private dataSource = new BehaviorSubject('default message');
  empId = this.dataSource.asObservable();

  constructor() { }

  changeValue(data:string) {
    this.dataSource.next(data);
  }

}