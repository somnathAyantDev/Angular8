import { Injectable, OnInit } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
import {registerDto} from '../register/registerDto.model';
import {ServerResponse} from '../server/serverResponse';
import { inventoryDto } from '../inventory/inventoryDto.model';
import { pricingDto } from '../pricing/pricingDto.model';

@Injectable()

export class EmpService {
  url: string;
  emp:registerDto;
  empArray:registerDto[];
  stock:inventoryDto;
  stockArray:inventoryDto[];

  constructor(private nativeHttp: HttpClient) {

  }

  //after calling the server side, the response is taken in observable and sent over as a response
  saveEmp(emp: registerDto): Observable<registerDto> {
    emp.id=12;
    //adding new employees to the portal
    this.url="http://localhost:3000/saveEmpData";
     //return this.nativeHttp.post(this.url,emp).map(res => res.json());
     return this.nativeHttp.post<registerDto>(this.url,emp);
  }
  
    //listing all available employees
  emps():Observable<registerDto[]> {
    this.url="http://localhost:3000/saveEmpData";
     //return this.nativeHttp.get(this.url).map(res => res.json());
     return this.nativeHttp.get<registerDto[]>(this.url);
  }

  updateEmp(emp: registerDto): Observable<registerDto> {
    alert(emp.id);
    this.url="http://localhost:3000/saveEmpData/"+emp.id;
     //return this.nativeHttp.post(this.url,emp).map(res => res.json());
     return this.nativeHttp.put<registerDto>(this.url,emp);
  }

    //listing  employee by id
    getEmpById(empId:string):Observable<registerDto> {
      this.url="http://localhost:3000/saveEmpData/"+parseInt(empId);
       //return this.nativeHttp.get(this.url).map(res => res.json());
       return this.nativeHttp.get<registerDto>(this.url);
    }

    deleteEmpById(emp:registerDto):Observable<registerDto> {
      this.url="http://localhost:3000/saveEmpData/"+emp.id;
       //return this.nativeHttp.get(this.url).map(res => res.json());
       return this.nativeHttp.delete<registerDto>(this.url);
    }

  inventory():Observable<inventoryDto[]>{
    this.url="http://localhost:3000/inventory";
    return this.nativeHttp.get<inventoryDto[]>(this.url);

  }

  pricing():Observable<pricingDto[]>{
    this.url="http://localhost:3000/pricing";
    return this.nativeHttp.get<pricingDto[]>(this.url);

  }

}
