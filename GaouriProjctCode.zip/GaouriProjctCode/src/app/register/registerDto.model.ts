export class registerDto{

    id:number;
    fname:string;
    lname:string;
    contact:number;
    salary:number;
    dept:string;
    designation:string;
    username:string;
    pwd:string;
}