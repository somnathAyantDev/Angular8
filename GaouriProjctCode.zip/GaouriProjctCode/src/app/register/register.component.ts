import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { registerDto } from './registerDto.model';
import { CustomValidators } from './custom-validators';
import { ServerResponse } from '../server/serverResponse';
import { EmpService } from '../services/employeeService.component';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  empForm: FormGroup;
  registerDtoObj: registerDto;
  
  Dept: any = ["IT","Network","Admin","Sales","Operations"];

  constructor(private fb: FormBuilder, private empService:EmpService, private route:Router) { }


  ngOnInit() {

    this.empForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'fname' : new FormControl('', [Validators.required,Validators.minLength(2)]),
      'lname' : new FormControl('', [Validators.required,Validators.minLength(2)]),
      'salary' : new FormControl('',[Validators.required]),
      'contact' : new FormControl('',[Validators.required]),
      
      'dept' : new FormControl('',[Validators.required]),
      'designation' : new FormControl('',[Validators.required]),
      'username': new FormControl('',[Validators.required, Validators.minLength(5), Validators.maxLength(12)]),
      'pwd': new FormControl('',[Validators.required,
       // 2. check whether the entered password has a number
       CustomValidators.patternValidator(/\d/, { hasNumber: true })])
});

  }

    // Choose dept using select dropdown
    changeDept(e) {
      console.log(e.value)
      //alert(e.target.value);
      this.dept.setValue(e.target.value, {
        onlySelf: true
      })
    }


  
    // Getter method to access formcontrols
    get dept() {
      return this.empForm.get('dept');
    }

  registerEmp(emp:registerDto){   //emp is the model class object
    
    this.empService.saveEmp(emp).subscribe((data) => {
        this.registerDtoObj=data
        alert(this.registerDtoObj.fname);
        alert("Employee saved !");
        this.route.navigate(['/login']) ;

    },
      err => {
        alert("Employee not saved !");
      },
      () => { console.log('Method Executed') }
    );
          
        }
}
