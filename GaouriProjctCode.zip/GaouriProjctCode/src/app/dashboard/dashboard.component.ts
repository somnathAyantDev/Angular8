import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  //Admin can have acces to all menubar
  //Account can have acces to pricing only
  //Inventory can have acces to inventory only
  
  role: string;
  userRole:boolean=false;
  userAdmin:boolean=false;
  userAccount:boolean=false;
  userInventory:boolean=false;
  constructor() { }

  ngOnInit() {
    
    /* this.role=sessionStorage.getItem("userName");
      if(this.role==="Admin"){
        this.userAdmin=true;
        this.userAccount=true;
        this.userInventory=true;
      }
      if(this.role==="Account"){
        this.userAccount=true;
      } if(this.role==="Inventory"){
        this.userInventory=true;
      } */




  //   this.empService.emps().subscribe((data) => {
  //     this.emps = data;

  //   },
  //     err => {
  //       alert("Employee not found !");
  //     },
  //     () => { console.log('Method Executed') }
  //   );

  //   for(var i=0;i<this.emps.length;i++){
  //   this.role = this.emps[i].designation;
  // }
  }

}
