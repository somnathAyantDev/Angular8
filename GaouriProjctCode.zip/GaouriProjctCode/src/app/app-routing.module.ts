import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {PageNotFoundComponent} from './page-not-found/page-not-found.component';
import { InventoryComponent } from './inventory/inventory.component';
import { PricingComponent } from './pricing/pricing.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AuthDashService } from './services/authDashboard.service';

const routes: Routes = [
  { path: 'login', component:LoginComponent},
  {path:'register', component:RegisterComponent},
  { path: '',   redirectTo: '/login', pathMatch:'full'},
  { path: 'dashBoard', component:DashboardComponent},
  { path: 'pricing', component:PricingComponent},
  { path: 'inventory', component:InventoryComponent},
  { path: 'logout', component:LoginComponent},
  { path: 'home', component:HomeComponent},
  {path: 'employee', loadChildren: () => import(`./emp/emp.module`).then(emp => emp.EmpModule) },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
