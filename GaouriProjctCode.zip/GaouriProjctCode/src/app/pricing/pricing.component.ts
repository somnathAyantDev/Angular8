import { Component, OnInit } from '@angular/core';
import { pricingDto } from './pricingDto.model';
import { EmpService } from '../services/employeeService.component';

@Component({
  selector: 'app-pricing',
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.css']
})
export class PricingComponent implements OnInit {

  price: pricingDto[] = [];

  constructor(private empService: EmpService) { }

  ngOnInit() {

    this.empService.pricing().subscribe((data) => {
      this.price = data;
    },
      err => {
        alert("Product not found !");
      },
      () => { console.log('Method Executed') }
    );


  }

}
