export class pricingDto{

    pid:number;
    name:string;
    req_quantity:number;
    unitPrice:number;
    total:number;
}